<?php
	$servername = "localhost";//数据库地址
    $username = "";//用户名
    $password = "";//密码
    $dbname = "";//数据库名称
?>
<?php
	$pwd=$_POST['pwd'];
	if (empty($pwd)) {
		echo "当前还未输入密码";
	}else{
		$npwd=jmppwd($pwd);
		$conn=mysql_connect($servername,$username,$password) or die("error connecting") ; 
		mysql_query("set names 'utf8'");
		mysql_select_db($dbname);
		$sql="UPDATE msapi_admin SET pass='$npwd' WHERE id=1";
		$res = mysql_query($sql);
	   	$row=mysql_affected_rows($conn);
	   	if(!empty($row)){
			echo "修改成功！";
		}else{
			echo "修改失败，请检查数据库连接";
		}
	}
	
	function jmppwd($p){
    	$password = $p;
		$salt = "msapi";
		$crypt=crypt($password, $salt);
		$md5crypt=md5($crypt);
		return $md5crypt;
    } 
?>
<!DOCTYPE html>
	<html>
	<head>
		<title>
			重置密码
		</title>
	</head>
	<body>
		<form action="findpwd.php" method="POST">
			请先输入一个密码<input type="text" name="pwd" style="width:300px; height:20px;" placeholder="请输入密码，字符串特殊字符都行，别输入汉字" />
			<input type="submit" >
			
		</form>
		请复制：<input type="text" name="pwd" style="width:300px; height:20px;" value="<?php echo $npwd;?>" placeholder="加密后" />
	</body>
</html>
